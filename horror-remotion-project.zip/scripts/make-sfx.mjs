// Deterministic SFX synth -> 16-bit mono WAV (44.1kHz). Run: node scripts/make-sfx.mjs
import fs from "node:fs";
import path from "node:path";
const SR = 44100;
const out = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(out, { recursive: true });

let seed = 7;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;

const lowpass = (x, fc) => {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y = (1 - a) * v + a * y));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
const bandpassSweep = (x, f0, f1) => {
  // moving one-pole band: lowpass(hp) with swept cutoff
  const n = x.length;
  let lpS = 0, lpS2 = 0;
  return x.map((v, i) => {
    const f = f0 * Math.pow(f1 / f0, i / n);
    const a = Math.exp((-2 * Math.PI * f) / SR);
    lpS = (1 - a) * v + a * lpS;
    const a2 = Math.exp((-2 * Math.PI * f * 2.2) / SR);
    lpS2 = (1 - a2) * lpS + a2 * lpS2;
    return lpS - lpS2 * 0.85;
  });
};
const tinyReverb = (x, mix = 0.12) => {
  const taps = [[0.021, 0.5], [0.037, 0.35], [0.053, 0.25], [0.071, 0.15]];
  const y = new Float32Array(x.length + Math.floor(0.12 * SR));
  x.forEach((v, i) => (y[i] += v));
  for (const [t, g] of taps) {
    const d = Math.floor(t * SR);
    x.forEach((v, i) => (y[i + d] += v * g * mix * 2));
  }
  return Array.from(y);
};
const env = (t, a, d) => (t < a ? t / a : Math.exp(-(t - a) / d));
const norm = (x, peak) => {
  const m = Math.max(...x.map(Math.abs));
  return x.map((v) => (v / m) * peak);
};
const fadeEnds = (x, inMs = 1.5, outMs = 10) => {
  const a = Math.max(1, Math.floor((inMs / 1000) * SR));
  const b = Math.max(1, Math.floor((outMs / 1000) * SR));
  return x.map((v, i) => v * Math.min(1, i / a, (x.length - 1 - i) / b));
};
const write = (name, x) => {
  x = fadeEnds(x);
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(path.join(out, name), buf);
};
const gen = (dur, f) => Array.from({ length: Math.floor(dur * SR) }, (_, i) => f(i / SR, i));

// soft pop: sine with fast downward pitch + small envelope  (~0.16s)
const pop = (base, dur = 0.16) => {
  let ph = 0;
  const raw = gen(dur, (t) => {
    const f = base * (1 + 1.6 * Math.exp(-t / 0.018));
    ph += (2 * Math.PI * f) / SR;
    return Math.sin(ph) * env(t, 0.004, 0.035);
  });
  return tinyReverb(lowpass(raw, 3800), 0.1);
};
// crisp click: high-passed short noise burst (~0.07s)
const click = (hp) => {
  const raw = gen(0.07, (t) => rnd() * env(t, 0.0008, 0.009));
  return tinyReverb(lowpass(highpass(raw, hp), 7000), 0.06);
};
// whoosh: band-passed noise sweep with fade in/out (<=0.8s)
const whoosh = (dur, f0, f1) => {
  const raw = gen(dur, () => rnd());
  const sw = bandpassSweep(raw, f0, f1);
  const sh = sw.map((v, i) => {
    const p = i / sw.length;
    return v * Math.pow(Math.sin(Math.PI * Math.pow(p, 0.8)), 1.6);
  });
  return tinyReverb(lowpass(sh, 5200), 0.1);
};
// soft thud: low sine, gentle attack, short decay (restrained)
const thud = () => {
  let ph = 0;
  const raw = gen(0.34, (t) => {
    const f = 62 * (1 + 0.9 * Math.exp(-t / 0.05));
    ph += (2 * Math.PI * f) / SR;
    return Math.sin(ph) * env(t, 0.012, 0.09);
  });
  return tinyReverb(lowpass(raw, 420), 0.08);
};
// chime / pluck: soft overtones, short decay
const chime = (f0) => {
  const raw = gen(0.38, (t) =>
    (Math.sin(2 * Math.PI * f0 * t) * 1 +
      Math.sin(2 * Math.PI * f0 * 2.76 * t) * 0.22 * Math.exp(-t / 0.06) +
      Math.sin(2 * Math.PI * f0 * 5.4 * t) * 0.08 * Math.exp(-t / 0.03)) *
    env(t, 0.006, 0.09)
  );
  return tinyReverb(lowpass(raw, 4200), 0.16);
};

const kit = {
  "pop.wav": [pop(520), 0.30],
  "pop2.wav": [pop(610, 0.14), 0.28],
  "click.wav": [click(2200), 0.30],
  "whoosh.wav": [whoosh(0.62, 380, 3200), 0.30],
  "whoosh-soft.wav": [whoosh(0.4, 500, 2400), 0.22],
  "thud.wav": [thud(), 0.34],
  "chime.wav": [chime(660), 0.24],
};
for (const [name, [x, peak]] of Object.entries(kit)) write(name, norm(x, peak));
console.log("SFX written:", Object.keys(kit).join(", "));
