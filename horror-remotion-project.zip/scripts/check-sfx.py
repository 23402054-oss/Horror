import wave, numpy as np, glob, os
for f in sorted(glob.glob("public/sfx/*.wav")):
    w=wave.open(f); n=w.getnframes(); sr=w.getframerate()
    x=np.frombuffer(w.readframes(n),dtype=np.int16).astype(float)/32768
    pk=abs(x).max(); rms=np.sqrt((x**2).mean())
    clip=(abs(x)>=0.999).sum()
    print(f"{os.path.basename(f):16s} dur={n/sr:.2f}s peak={pk:.3f} rms={rms:.3f} clipped={clip}")
