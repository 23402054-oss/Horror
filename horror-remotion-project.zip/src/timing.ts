// SRT থেকে সব সময়-হিসাব। হাতে কোনো ফ্রেম নম্বর বসানো নেই।
import { CUES } from "./cues.generated";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
export const TAIL = Math.round(FPS * 1.2); // শেষ cue-র পর সমাপ্তির নীরবতা

export const cue = (n: number) => {
  const c = CUES[n - 1];
  const from = Math.round(c.start * FPS);
  const to = Math.round(c.end * FPS);
  return { from, to, dur: to - from, text: c.text };
};

export const TOTAL_FRAMES = cue(CUES.length).to + TAIL;

// অর্থ অনুযায়ী সিন: [প্রথম cue, শেষ cue]
const PLAN: Array<[number, number]> = [
  [1, 2], [3, 3], [4, 4], [5, 5], [6, 7], [8, 8],
  [9, 10], [11, 12], [13, 14], [15, 15], [16, 17], [18, 19],
];

export type SceneDef = { idx: number; firstCue: number; lastCue: number; from: number; to: number; dur: number };

export const SCENES: SceneDef[] = PLAN.map(([a, b], i) => {
  const from = i === 0 ? 0 : cue(a).from - LEAD;
  const next = PLAN[i + 1];
  const to = next ? cue(next[0]).from - LEAD : TOTAL_FRAMES;
  return { idx: i, firstCue: a, lastCue: b, from, to, dur: to - from };
});

/** cue n-এর কথা সিনের কততম লোকাল ফ্রেমে শুরু হয় */
export const spoken = (s: SceneDef, n: number) => cue(n).from - s.from;
/** cue n-এর ভিজ্যুয়াল এন্ট্রি (কথার LEAD ফ্রেম আগে) */
export const enter = (s: SceneDef, n: number) => Math.max(0, spoken(s, n) - LEAD);
/** cue-র ভেতরে অনুপাত দিয়ে অবস্থান (একাধিক আইটেম সমান ব্যবধানে) */
export const within = (s: SceneDef, n: number, ratio: number) =>
  Math.max(0, Math.round(spoken(s, n) + cue(n).dur * ratio) - LEAD);
