import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { SCENES } from "./timing";
import { PreviewAudio } from "./PreviewAudio";
import { Scene1, Scene2, Scene3, Scene4 } from "./scenes/a";
import { Scene5, Scene6, Scene7, Scene8 } from "./scenes/b";
import { Scene9, Scene10, Scene11, Scene12 } from "./scenes/c";

const COMPS = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7, Scene8, Scene9, Scene10, Scene11, Scene12];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bgDeep, fontFamily: theme.fonts.display }}>
    <PreviewAudio />
    {SCENES.map((s) => {
      const C = COMPS[s.idx];
      return (
        <Sequence key={s.idx} from={s.from} durationInFrames={s.dur}>
          <C s={s} />
        </Sequence>
      );
    })}
  </AbsoluteFill>
);
