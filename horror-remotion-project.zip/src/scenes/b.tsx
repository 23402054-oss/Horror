import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, withAlpha } from "../theme";
import { SceneDef, enter, within, spoken, cue } from "../timing";
import { Entrance, KenBurns, SceneShell, Sfx, clampX } from "../fx";
import { MaskLine, Sweep, TypeWords, Words, drawProps, useDraw } from "../text";
import { Glass, Pill } from "../ui";

/* ═══════════ সিন ৫ — রিপল + Timeline সিঁড়ি (cue ৬-৭) ═══════════ */
export const Scene5: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e7 = enter(s, 7);
  const phaseB = interpolate(frame, [e7, e7 + 18], [0, 1], { easing: theme.ease.inOut, ...clampX });
  // ধাপ ১: রিপল ঘুরে কোণে ছোট হয়
  const rx = interpolate(phaseB, [0, 1], [520, 250]);
  const ry = interpolate(phaseB, [0, 1], [540, 250]);
  const rs = interpolate(phaseB, [0, 1], [1, 0.42]);
  const rippleOp = interpolate(phaseB, [0, 1], [1, 0.55]);
  // সিঁড়ি
  const steps = 7;
  const x0 = 250, y0 = 930, dx = 175, dy = 95;
  const pts: Array<[number, number]> = [[x0, y0]];
  for (let i = 0; i < steps; i++) { pts.push([x0 + dx * i, y0 - dy * (i + 1)]); pts.push([x0 + dx * (i + 1), y0 - dy * (i + 1)]); }
  const path = pts.map((p, i) => `${i ? "L" : "M"}${p[0]} ${p[1]}`).join(" ");
  const drawP = useDraw(e7 + 4, 38);
  const climbStart = e7 + 30;
  const climbEnd = s.dur - 14;
  const cp = interpolate(frame, [climbStart, climbEnd], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const stepF = cp * steps;
  const si = Math.min(steps - 1, Math.floor(stepF));
  const within1 = stepF - si;
  const hop = Math.sin(Math.min(1, within1 * 1.3) * Math.PI) * 26;
  const dotX = x0 + dx * si + dx * 0.5 * Math.min(1, within1 * 1.4);
  const dotY = y0 - dy * (si + 1) - 28 - hop * (cp >= 1 ? 0 : 1) + (cp >= 1 ? 0 : 0);
  const tRipple = 6;
  return (
    <SceneShell dur={s.dur} variant={0} bg={{ src: theme.img.hallway, zoomFrom: 1.05, zoomTo: 1.15, dim: 0.78, opacity: 0.55 }}>
      {/* রিপল */}
      <div style={{ position: "absolute", left: rx - 270, top: ry - 270, width: 540, height: 540, transform: `scale(${rs})`, opacity: rippleOp }}>
        <svg width={540} height={540} viewBox="-270 -270 540 540" style={{ overflow: "visible" }}>
          {Array.from({ length: 5 }).map((_, i) => {
            const t = ((frame + i * 18) % 90) / 90;
            const r = 30 + t * 240;
            return <circle key={i} r={r} fill="none" stroke={theme.colors.hero} strokeWidth={4 - t * 3} opacity={(1 - t) * 0.9} />;
          })}
          <circle r={22 + Math.sin(frame / 5) * 3} fill={theme.colors.hero} style={{ filter: `drop-shadow(0 0 22px ${theme.colors.glowHero})` }} />
        </svg>
      </div>
      {/* ধাপ ১ টেক্সট */}
      <div style={{ position: "absolute", left: 1010, top: 330 }}>
        <MaskLine text="ওপরতলা থেকে" size={74} color={theme.colors.textDim} delay={tRipple + 6} exitAt={e7 - 2} />
        <div style={{ height: 14 }} />
        <MaskLine text="কান্নার শব্দ" size={190} delay={tRipple + 16} dur={24} exitAt={e7} />
      </div>
      {/* ধাপ ২: সিঁড়ি */}
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        <path d={path} fill="none" stroke={theme.colors.line} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" {...drawProps(drawP)} />
        {pts.filter((_, i) => i % 2 === 0 && i > 0).map(([x, y], i) => {
          const p = interpolate(frame - (e7 + 10 + i * 4), [0, 10], [0, 1], { easing: theme.ease.out, ...clampX });
          return <circle key={i} cx={x} cy={y} r={9 * p} fill={i + 1 <= stepF ? theme.colors.hero : theme.colors.textDim} />;
        })}
        {frame >= climbStart - 4 && (
          <g opacity={interpolate(frame, [climbStart - 4, climbStart + 6], [0, 1], clampX)}>
            <circle cx={dotX} cy={dotY} r={22} fill={theme.colors.accent} style={{ filter: `drop-shadow(0 0 16px ${theme.colors.glowAccent})` }} />
          </g>
        )}
      </svg>
      <div style={{ position: "absolute", left: 1010, top: 700, opacity: phaseB }}>
        <Words text="ধীরে ধীরে" size={78} color={theme.colors.textDim} delay={e7 + 8} per={5} />
        <div style={{ height: 6 }} />
        <Words text="সিঁড়ি বেয়ে ওপরে" size={120} delay={e7 + 20} per={6} hi={[2]} hiColor={theme.colors.hero} />
      </div>
      <Sfx at={tRipple - 3} name="pop" rate={0.94} />
      <Sfx at={e7 - 3} name="whooshSoft" rate={0.96} vol={0.8} />
      <Sfx at={climbStart + Math.round((climbEnd - climbStart) * 0.3)} name="click" rate={0.96} vol={0.7} />
      <Sfx at={climbStart + Math.round((climbEnd - climbStart) * 0.65)} name="click" rate={1.06} vol={0.7} />
    </SceneShell>
  );
};

/* ═══════════ সিন ৬ — লাইন-ড্র দরজা খোলা (cue ৮) ═══════════ */
export const Scene6: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tOpen = within(s, 8, 0.28);
  const open = spring({ frame: frame - tOpen, fps, config: theme.spring.eerie });
  const ang = open * -64;
  const frameP = useDraw(2, 30);
  const light = interpolate(open, [0, 1], [0, 1]);
  const dw = 400, dh = 640, dx = 250, dy = 270;
  return (
    <SceneShell dur={s.dur} variant={1} warm={0.5}>
      {/* মেঝেতে আলো */}
      <div style={{ position: "absolute", left: dx - 40, top: dy + dh - 8, width: 640, height: 220, opacity: light, background: `linear-gradient(180deg, ${withAlpha("accent", 0.5)}, transparent)`, clipPath: "polygon(8% 0, 62% 0, 100% 100%, 0 100%)", filter: "blur(18px)", transform: `scaleX(${0.4 + light * 0.8})`, transformOrigin: "10% 0" }} />
      {/* দরজার ভেতরের আলো */}
      <div style={{ position: "absolute", left: dx, top: dy, width: dw, height: dh, background: `radial-gradient(ellipse at 20% 50%, ${withAlpha("accent", 0.95 * light)}, ${withAlpha("accent", 0.25 * light)} 70%, ${withAlpha("black", 0.9)} 100%)`, borderRadius: "6px 6px 0 0" }} />
      <div style={{ position: "absolute", left: dx, top: dy, width: dw, height: dh, perspective: 1400 }}>
        <div style={{ position: "absolute", inset: 0, transformOrigin: "left center", transform: `rotateY(${ang}deg)`, background: `linear-gradient(90deg, ${theme.colors.bgAlt}, ${theme.colors.bg})`, border: `3px solid ${theme.colors.line}`, borderRadius: "6px 6px 0 0", boxShadow: theme.shadow.soft }}>
          <div style={{ position: "absolute", left: 40, top: 50, right: 40, height: 230, border: `2px solid ${theme.colors.line}`, borderRadius: 6 }} />
          <div style={{ position: "absolute", left: 40, bottom: 60, right: 40, height: 230, border: `2px solid ${theme.colors.line}`, borderRadius: 6 }} />
          <div style={{ position: "absolute", right: 28, top: 320, width: 18, height: 18, borderRadius: 18, background: theme.colors.accent, boxShadow: `0 0 14px ${theme.colors.glowAccent}` }} />
        </div>
      </div>
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        <path d={`M${dx - 22} ${dy + dh + 12} L${dx - 22} ${dy - 22} L${dx + dw + 22} ${dy - 22} L${dx + dw + 22} ${dy + dh + 12}`} fill="none" stroke={theme.colors.textDim} strokeWidth={8} strokeLinejoin="round" {...drawProps(frameP)} />
        <path d={`M120 ${dy + dh + 12} L1800 ${dy + dh + 12}`} stroke={theme.colors.line} strokeWidth={4} fill="none" {...drawProps(frameP)} />
      </svg>
      <Entrance delay={8} rise={20} config="pop" style={{ position: "absolute", left: dx + dw / 2 - 70, top: dy - 110 }}>
        <Pill size={54} color={theme.colors.accent}>১৩</Pill>
      </Entrance>
      <div style={{ position: "absolute", left: 960, top: 300 }}>
        <Words text="নিজে থেকেই" size={104} color={theme.colors.textDim} delay={6} per={5} />
        <div style={{ height: 8 }} />
        <div style={{ display: "flex", columnGap: 28 }}>
          <Sweep delay={tOpen + 4} color={withAlpha("hero", 0.9)} pad={26}>
            <Words text="খুলে গেল" size={190} color={theme.colors.bg} delay={tOpen - 2} per={6} cfg="pop" />
          </Sweep>
        </div>
      </div>
      <Sfx at={tOpen - 3} name="click" rate={0.9} />
      <Sfx at={tOpen + 14} name="chime" rate={0.9} vol={0.85} />
    </SceneShell>
  );
};

/* ═══════════ সিন ৭ — Before / After আয়না (cue ৯-১০) ═══════════ */
const Arch: React.FC<{ w: number; h: number; children: React.ReactNode; stroke: string; drawP: number }> = ({ w, h, children, stroke, drawP }) => {
  const r = w / 2;
  const d = `M3 ${h - 3} L3 ${r} A${r - 3} ${r - 3} 0 0 1 ${w - 3} ${r} L${w - 3} ${h - 3} Z`;
  return (
    <div style={{ position: "relative", width: w, height: h }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: `${r}px ${r}px 18px 18px`, overflow: "hidden" }}>{children}</div>
      <svg width={w} height={h} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
        <path d={d} fill="none" stroke={stroke} strokeWidth={7} strokeLinejoin="round" {...drawProps(drawP)} />
      </svg>
    </div>
  );
};

export const Scene7: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e10 = enter(s, 10);
  const dL = useDraw(2, 30);
  const dR = useDraw(e10 - 4, 30);
  const rightP = interpolate(frame, [e10 - 6, e10 + 14], [0, 1], { easing: theme.ease.out, ...clampX });
  const leftDim = interpolate(frame, [e10, e10 + 20], [1, 0.55], { easing: theme.ease.inOut, ...clampX });
  const AW = 560, AH = 700;
  // চুল আঁচড়ানোর স্ট্রোক
  const strokes = Array.from({ length: 4 }).map((_, i) => {
    const t = ((frame * 1.4 + i * 22) % 88) / 88;
    return { t, i };
  });
  // ডান আয়নার "প্রতিবিম্ব" ড্যাশড আউটলাইন, জ্বলে নিভে যায়
  const ghostOp = interpolate(frame - (e10 + 10), [0, 10, 34, 52], [0, 0.8, 0.8, 0], clampX);
  const strike = interpolate(frame - (e10 + 22), [0, 14], [0, 1], { easing: theme.ease.out, ...clampX });
  return (
    <SceneShell dur={s.dur} variant={2}>
      {/* বাঁ */}
      <div style={{ position: "absolute", left: 190, top: 150, opacity: leftDim }}>
        <Entrance delay={2} rise={50} config="smooth">
          <Arch w={AW} h={AH} stroke={theme.colors.hero} drawP={dL}>
            <KenBurns src={theme.img.ghost} zoomFrom={1.0} zoomTo={1.12} panX={-14} dim={0.12} focus="80% 45%" />
            <svg width={AW} height={AH} style={{ position: "absolute", inset: 0 }}>
              {strokes.map(({ t, i }) => (
                <path key={i} d={`M${330 + i * 22} ${150 + t * 60} C ${300 + i * 22} ${260 + t * 80}, ${290 + i * 22} ${330 + t * 80}, ${280 + i * 24} ${430 + t * 60}`} fill="none" stroke={theme.colors.text} strokeWidth={3} strokeLinecap="round" opacity={Math.sin(t * Math.PI) * 0.55} />
              ))}
            </svg>
          </Arch>
        </Entrance>
        <div style={{ marginTop: 26, display: "flex", alignItems: "center", gap: 20 }}>
          <Pill size={44}>মেয়েটি</Pill>
          <Words text="চুল আঁচড়াচ্ছিল" size={58} color={theme.colors.textDim} delay={within(s, 9, 0.35)} per={5} />
        </div>
      </div>
      {/* মাঝের "অথচ" */}
      <Entrance delay={e10 - 8} rise={20} config="pop" style={{ position: "absolute", left: 960 - 110, top: 430 }}>
        <Pill size={64} color={theme.colors.accent} bg={theme.colors.bg}>অথচ</Pill>
      </Entrance>
      {/* ডান */}
      <div style={{ position: "absolute", left: 1170, top: 150, opacity: rightP }}>
        <Arch w={AW} h={AH} stroke={theme.colors.textDim} drawP={dR}>
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(160deg, ${theme.colors.bgAlt}, ${theme.colors.bgDeep})` }} />
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(115deg, transparent ${((frame * 1.2) % 160) - 30}%, ${withAlpha("text", 0.08)} ${((frame * 1.2) % 160) - 20}%, transparent ${((frame * 1.2) % 160) - 8}%)` }} />
          <svg width={AW} height={AH} style={{ position: "absolute", inset: 0 }}>
            <g opacity={ghostOp} fill="none" stroke={theme.colors.hero} strokeWidth={5} strokeDasharray="14 12" strokeLinecap="round">
              <circle cx={AW / 2} cy={300} r={78} />
              <path d={`M${AW / 2 - 190} ${AH - 20} C ${AW / 2 - 190} 480, ${AW / 2 - 80} 400, ${AW / 2} 400 C ${AW / 2 + 80} 400, ${AW / 2 + 190} 480, ${AW / 2 + 190} ${AH - 20}`} />
            </g>
          </svg>
        </Arch>
        <div style={{ marginTop: 26, display: "flex", alignItems: "center", gap: 22 }}>
          <span style={{ position: "relative", display: "inline-block" }}>
            <Words text="প্রতিবিম্ব" size={92} color={theme.colors.text} delay={e10 + 6} per={4} />
            <div style={{ position: "absolute", left: -6, top: "54%", height: 8, width: `${strike * 104}%`, background: theme.colors.accent, borderRadius: 4, boxShadow: `0 0 18px ${theme.colors.glowAccent}` }} />
          </span>
          <Words text="নেই" size={92} color={theme.colors.accent} glow={theme.colors.glowAccent} delay={e10 + 24} cfg="pop" />
        </div>
      </div>
      <Sfx at={0} name="pop" rate={1.02} vol={0.8} />
      <Sfx at={e10 - 3} name="pop2" rate={0.96} />
      <Sfx at={e10 + 22 - 3} name="click" rate={1.04} />
    </SceneShell>
  );
};

/* ═══════════ সিন ৮ — চ্যাট UI (টাইপরাইটার শব্দ ধরে) (cue ১১-১২) ═══════════ */
export const Scene8: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e11 = enter(s, 11), e12 = enter(s, 12);
  const jit = (k: number) => Math.sin(frame * 3.1 + k) * 2.4;
  const typing = frame > e12 - 22 && frame < e12 + 4;
  return (
    <SceneShell dur={s.dur} variant={3}>
      <Entrance delay={2} rise={40} config="smooth" style={{ position: "absolute", left: 260, top: 175 }}>
        <Glass w={1400} h={720} style={{ position: "relative" }}>
          {/* হেডার */}
          <div style={{ height: 112, borderBottom: `1.5px solid ${theme.colors.line}`, display: "flex", alignItems: "center", padding: "0 44px", gap: 22 }}>
            <Avatar t="মে" bg={theme.colors.hero} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 52, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text }}>তেরো নম্বর ঘর</div>
            <div style={{ marginLeft: "auto", width: 16, height: 16, borderRadius: 16, background: theme.colors.accent, boxShadow: `0 0 16px ${theme.colors.glowAccent}`, opacity: 0.6 + 0.4 * Math.sin(frame / 8) }} />
          </div>
          {/* মেয়েটির বাবল */}
          <div style={{ position: "absolute", left: 44, top: 170, maxWidth: 940 }}>
            <Entrance delay={e11 - 2} rise={26} config="pop">
              <div style={{ marginBottom: 12, fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: 38, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.textDim }}>মেয়েটি</div>
              <div style={{ padding: "28px 44px 36px", borderRadius: "30px 30px 30px 8px", background: withAlpha("hero", 0.14), border: `1.5px solid ${theme.colors.hero}` }}>
                <TypeWords text="তুমি এত দেরি করলে কেন?" size={78} delay={e11 + 6} per={7} />
              </div>
            </Entrance>
          </div>
          {/* টাইপিং ডটস */}
          {typing && (
            <div style={{ position: "absolute", right: 70, top: 470, display: "flex", gap: 12 }}>
              {[0, 1, 2].map((i) => (
                <div key={i} style={{ width: 20, height: 20, borderRadius: 20, background: theme.colors.textDim, transform: `translateY(${Math.sin(frame / 4 - i) * 7}px)` }} />
              ))}
            </div>
          )}
          {/* রাফির বাবল */}
          <div style={{ position: "absolute", right: 44, top: 430, maxWidth: 900, display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
            <Entrance delay={e12} rise={26} config="pop">
              <div style={{ marginBottom: 12, textAlign: "right", fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: 38, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.textDim }}>রাফি</div>
              <div style={{ padding: "28px 44px 36px", borderRadius: "30px 30px 8px 30px", background: withAlpha("surface", 0.95), border: `1.5px solid ${theme.colors.line}`, transform: `translate(${jit(0)}px, ${jit(2)}px)` }}>
                <TypeWords text="আপনি আমাকে চেনেন?" size={78} delay={e12 + 8} per={7} color={theme.colors.text} />
              </div>
            </Entrance>
          </div>
        </Glass>
      </Entrance>
      <Sfx at={e11 - 3} name="pop" />
      <Sfx at={e12 - 3} name="pop2" rate={0.97} />
    </SceneShell>
  );
};

const Avatar: React.FC<{ t: string; bg: string }> = ({ t, bg }) => (
  <div style={{ width: 70, height: 70, borderRadius: 70, background: withAlpha("hero", 0.18), border: `2px solid ${bg}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 34, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text }}>{t}</div>
);
export { spoken, cue, AbsoluteFill };
