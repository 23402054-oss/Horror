import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme, withAlpha } from "../theme";
import { SceneDef, enter, within, cue } from "../timing";
import { Entrance, SceneShell, Sfx, clampX } from "../fx";
import { BnCounter, MaskLine, Words, drawProps, useDraw } from "../text";

/* ═══════════ সিন ৯ — মুখহীন মেয়ে + Checklist (cue ১৩-১৪) ═══════════ */
export const Scene9: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const turnStart = enter(s, 13) + 14;
  const turnDur = 44;
  const tp = interpolate(frame, [turnStart, turnStart + turnDur], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const th = tp * Math.PI;
  const sx = Math.max(0.025, Math.abs(Math.cos(th)));
  const showFace = tp >= 0.5;
  const sway = Math.sin(frame / 26) * 6;
  const ftEnd = turnStart + turnDur;
  const fadeF = interpolate(frame, [ftEnd + 14, ftEnd + 40], [1, 0], { easing: theme.ease.inOut, ...clampX });
  const fDash = interpolate(frame, [ftEnd, ftEnd + 16], [0, 1], { easing: theme.ease.out, ...clampX });
  const rows = ["চোখ", "নাক", "মুখ"];
  const rowT = rows.map((_, i) => within(s, 14, 0.04 + i * 0.3)); // সমান ব্যবধান
  return (
    <SceneShell dur={s.dur} variant={0}>
      <Entrance delay={2} rise={40} config="smooth" style={{ position: "absolute", left: 250, top: 160 }}>
        <svg width={520} height={760} viewBox="0 0 520 760" style={{ overflow: "visible", transform: `translateX(${sway * (1 - tp)}px) scaleX(${sx})`, transformOrigin: "260px 380px" }}>
          <defs>
            <radialGradient id="faceG" cx="50%" cy="40%" r="65%">
              <stop offset="0%" stopColor={theme.colors.pale} />
              <stop offset="100%" stopColor={theme.colors.paleDark} />
            </radialGradient>
          </defs>
          {/* কাঁধ */}
          <path d="M10 760 C 30 640 130 590 215 580 L 305 580 C 400 590 490 640 510 760 Z" fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={3} />
          {showFace ? (
            <>
              <path d="M215 500 L215 585 L305 585 L305 500 Z" fill={theme.colors.paleDark} />
              <ellipse cx={260} cy={310} rx={150} ry={200} fill="url(#faceG)" />
              <path d="M110 300 C 100 150 170 80 260 80 C 350 80 420 150 410 300 C 380 190 330 150 260 150 C 190 150 140 190 110 300 Z" fill={theme.colors.bgDeep} />
              <g opacity={fadeF * fDash} fill="none" stroke={theme.colors.hero} strokeWidth={5} strokeDasharray="12 10" strokeLinecap="round">
                <ellipse cx={200} cy={300} rx={28} ry={15} />
                <ellipse cx={320} cy={300} rx={28} ry={15} />
                <path d="M260 320 L248 385 C 255 392 270 392 278 385" />
                <path d="M212 445 C 240 462 280 462 308 445" />
              </g>
            </>
          ) : (
            <>
              <ellipse cx={260} cy={310} rx={160} ry={212} fill={theme.colors.bgDeep} stroke={theme.colors.line} strokeWidth={3} />
              <path d="M260 120 C 190 220 190 400 230 520 M260 120 C 330 220 330 400 290 520 M260 120 L260 540" fill="none" stroke={theme.colors.line} strokeWidth={3} />
              <path d="M130 330 C 110 450 90 540 70 640 L450 640 C 430 540 410 450 390 330" fill={theme.colors.bgDeep} opacity={0.9} />
            </>
          )}
        </svg>
      </Entrance>
      <div style={{ position: "absolute", left: 1010, top: 210 }}>
        <Words text="তার মুখে কোনো" size={84} color={theme.colors.textDim} delay={within(s, 14, 0) - 8} per={5} />
        <div style={{ height: 28 }} />
        {rows.map((r, i) => (
          <CheckRow key={r} label={r} delay={rowT[i]} />
        ))}
      </div>
      <Sfx at={turnStart - 3} name="whooshSoft" rate={0.92} vol={0.75} />
      {rowT.map((t, i) => (
        <Sfx key={i} at={t + 14} name="click" rate={0.95 + i * 0.05} vol={0.8} />
      ))}
    </SceneShell>
  );
};

const CheckRow: React.FC<{ label: string; delay: number }> = ({ label, delay }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame - delay - 8, [0, 12], [0, 1], { easing: theme.ease.out, ...clampX });
  return (
    <Entrance delay={delay} rise={26} config="snappy" style={{ display: "flex", alignItems: "center", gap: 36, marginBottom: 20 }}>
      <svg width={96} height={96} viewBox="0 0 96 96">
        <circle cx={48} cy={48} r={42} fill="none" stroke={theme.colors.line} strokeWidth={5} />
        <path d="M30 30 L66 66 M66 30 L30 66" stroke={theme.colors.accent} strokeWidth={9} strokeLinecap="round" {...drawProps(p)} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.glowAccent})` }} />
      </svg>
      <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 150, lineHeight: 1.25, letterSpacing: 0, color: theme.colors.text }}>{label}</div>
    </Entrance>
  );
};

/* ═══════════ সিন ১০ — Counter রিং: "২০ বছর আগে" (cue ১৫) ═══════════ */
export const Scene10: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const tNum = within(s, 15, 0.12);
  const p = interpolate(frame - tNum, [0, 54], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const rot = -frame * 0.35;
  const R = 300;
  const filled = Math.round(p * 20);
  const ringIn = useDraw(2, 26);
  const tEnd = within(s, 15, 0.7);
  return (
    <SceneShell dur={s.dur} variant={1} warm={0.3}>
      <div style={{ position: "absolute", left: 960 - 330, top: 510 - 330, width: 660, height: 660, opacity: ringIn }}>
        <svg width={660} height={660} viewBox="-330 -330 660 660" style={{ overflow: "visible" }}>
          <g transform={`rotate(${rot})`}>
            {Array.from({ length: 20 }).map((_, i) => {
              const a = (i / 20) * Math.PI * 2;
              const on = i < filled;
              const pop = interpolate(frame - tNum - (i / 20) * 54, [0, 8], [1.5, 1], { easing: theme.ease.out, ...clampX });
              return (
                <line key={i} x1={Math.sin(a) * (R - 34)} y1={-Math.cos(a) * (R - 34)} x2={Math.sin(a) * (R - 34 + 34 * pop)} y2={-Math.cos(a) * (R - 34 + 34 * pop)} stroke={on ? theme.colors.hero : theme.colors.line} strokeWidth={on ? 10 : 6} strokeLinecap="round" />
              );
            })}
          </g>
        </svg>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 58, display: "flex", justifyContent: "center" }}>
        <Words text="তুমি তো" size={76} color={theme.colors.textDim} delay={4} per={5} align="center" />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 262, display: "flex", justifyContent: "center", lineHeight: 1 }}>
        <Entrance delay={tNum - 6} rise={30} config="pop">
          <BnCounter to={20} delay={tNum} size={330} color={theme.colors.hero} glow={theme.colors.glowHero} />
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 622, display: "flex", justifyContent: "center" }}>
        <Words text="বছর আগেই" size={82} delay={tNum + 24} per={5} align="center" />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 870, display: "flex", justifyContent: "center" }}>
        <Words text="মারা গিয়েছিলে" size={124} color={theme.colors.accent} glow={theme.colors.glowAccent} delay={tEnd} per={6} cfg="pop" align="center" />
      </div>
      <Sfx at={tNum - 3} name="thud" rate={0.96} />
      <Sfx at={tEnd - 3} name="pop" rate={0.9} vol={0.8} />
    </SceneShell>
  );
};

/* ═══════════ সিন ১১ — আয়না + কঙ্কাল (cue ১৬-১৭) ═══════════ */
export const Scene11: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e17 = enter(s, 17);
  const archP = useDraw(2, 32);
  const run = interpolate(frame, [8, e17], [0, 1], { easing: theme.ease.in, ...clampX });
  const sil = interpolate(frame, [e17 - 2, e17 + 8], [1, 0], clampX);
  const skP = interpolate(frame, [e17, e17 + 42], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const f = frame - e17;
  const flick = f < 0 ? 0 : f > 24 || Math.sin(f * 7.7) > -0.25 ? 1 : 0.2;
  const AW = 640, AH = 820, ax = 1060, ay = 130;
  const archD = `M3 ${AH - 3} L3 ${AW / 2} A${AW / 2 - 3} ${AW / 2 - 3} 0 0 1 ${AW - 3} ${AW / 2} L${AW - 3} ${AH - 3} Z`;
  const sweep = ((frame * 1.3) % 170) - 30;
  return (
    <SceneShell dur={s.dur} variant={2}>
      <div style={{ position: "absolute", left: ax, top: ay, width: AW, height: AH }}>
        <div style={{ position: "absolute", inset: 0, borderRadius: `${AW / 2}px ${AW / 2}px 18px 18px`, overflow: "hidden", background: `linear-gradient(170deg, ${theme.colors.bgAlt}, ${theme.colors.bgDeep})` }}>
          <div style={{ position: "absolute", inset: 0, background: `linear-gradient(115deg, transparent ${sweep}%, ${withAlpha("text", 0.07)} ${sweep + 10}%, transparent ${sweep + 22}%)` }} />
        </div>
        <svg width={AW} height={AH} viewBox={`0 0 ${AW} ${AH}`} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
          <path d={archD} fill="none" stroke={theme.colors.textDim} strokeWidth={8} strokeLinejoin="round" {...drawProps(archP)} />
          {/* রাফির ছায়া, এগিয়ে আসে */}
          <g opacity={sil * 0.85} transform={`translate(${AW / 2} ${AH - 60}) scale(${0.28 + run * 0.78}) translate(-200 -420)`}>
            <circle cx={200} cy={150} r={70} fill={theme.colors.paleDark} />
            <path d="M60 420 C 60 300 120 250 200 250 C 280 250 340 300 340 420 Z" fill={theme.colors.paleDark} />
          </g>
          {/* কঙ্কাল */}
          <g opacity={flick} transform={`translate(${AW / 2 - 200} 70) scale(0.88)`} fill="none" stroke={theme.colors.hero} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glowHero})` }}>
            <path d="M200 40 C 110 40 60 110 60 190 C 60 245 85 275 115 295 L 115 345 C 115 360 125 368 140 368 L 260 368 C 275 368 285 360 285 345 L 285 295 C 315 275 340 245 340 190 C 340 110 290 40 200 40 Z" {...drawProps(skP)} />
            <ellipse cx={145} cy={205} rx={38} ry={44} {...drawProps(Math.min(1, skP * 1.4))} />
            <ellipse cx={255} cy={205} rx={38} ry={44} {...drawProps(Math.min(1, skP * 1.4))} />
            <path d="M200 245 L182 290 L218 290 Z" {...drawProps(skP)} />
            <path d="M140 368 L140 398 L260 398 L260 368 M165 368 L165 398 M190 368 L190 398 M215 368 L215 398 M240 368 L240 398" {...drawProps(skP)} />
            <path d="M200 398 L200 740" {...drawProps(skP)} />
            <path d="M200 440 C 130 430 95 450 85 500 M200 500 C 125 490 90 515 78 570 M200 560 C 130 552 100 575 92 625 M200 620 C 140 615 112 635 108 680" {...drawProps(skP)} />
            <path d="M200 440 C 270 430 305 450 315 500 M200 500 C 275 490 310 515 322 570 M200 560 C 270 552 300 575 308 625 M200 620 C 260 615 288 635 292 680" {...drawProps(skP)} />
          </g>
        </svg>
      </div>
      <div style={{ position: "absolute", left: 130, top: 250 }}>
        <Words text="দৌড়ে" size={80} color={theme.colors.textDim} delay={4} per={5} exitAt={e17 + 6} />
        <div style={{ height: 8 }} />
        <MaskLine text="আয়নার সামনে" size={118} delay={12} exitAt={e17 + 6} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 300 }}>
        <Words text="প্রতিবিম্বের বদলে" size={76} color={theme.colors.textDim} delay={e17 + 14} per={5} />
        <div style={{ height: 12 }} />
        <MaskLine text="কঙ্কাল" size={250} color={theme.colors.accent} glow={theme.colors.glowAccent} delay={e17 + 26} dur={24} />
      </div>
      <Sfx at={e17 - 3} name="whooshSoft" rate={1.04} vol={0.75} />
      <Sfx at={e17 + 6} name="chime" rate={0.8} vol={0.9} />
    </SceneShell>
  );
};

/* ═══════════ সিন ১২ — সমাপ্তি: হাসির ওয়েভ + "পরের শিকার…" (cue ১৮-১৯) ═══════════ */
export const Scene12: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e19 = enter(s, 19);
  const c18 = cue(18);
  const wave = (x: number) => {
    const bursts = [0.12, 0.32, 0.52, 0.7];
    const env = bursts.reduce((a, b) => a + Math.exp(-Math.pow((frame - (enter(s, 18) + c18.dur * b)) / 7, 2)), 0);
    const calm = interpolate(frame, [e19 - 6, e19 + 12], [1, 0.12], { easing: theme.ease.inOut, ...clampX });
    return Math.sin(x / 38 + frame / 3) * (10 + env * 110) * calm * Math.sin((x / 1640) * Math.PI);
  };
  const d = Array.from({ length: 83 }).map((_, i) => `${i ? "L" : "M"}${140 + i * 20} ${Math.round(815 + wave(i * 20))}`).join(" ");
  const tShik = within(s, 19, 0.62);
  const tPor = within(s, 19, 0.5);
  const crackP = interpolate(frame - (tShik + 8), [0, 14], [0, 1], { easing: theme.ease.out, ...clampX });
  const jit = frame > tShik ? Math.sin(frame * 5.3) * 3 : 0;
  const endFade = interpolate(frame, [s.dur - 30, s.dur - 2], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const aOut = interpolate(frame, [e19 - 4, e19 + 6], [1, 0], { easing: theme.ease.in, ...clampX });
  const crack = "M960 540 L930 470 L965 410 L925 340 L960 260 L930 170 L955 80 L940 0 M960 540 L1010 590 L985 650 L1040 720 L1010 800 L1070 880 L1050 960 L1090 1080 M960 540 L880 560 L860 610 L790 640 L770 700 L690 730";
  return (
    <SceneShell dur={s.dur} variant={3} noExit bg={{ src: theme.img.ghost, zoomFrom: 1.02, zoomTo: 1.2, panX: 30, dim: 0.62, opacity: 0.8 }}>
      <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 50%, transparent 20%, ${withAlpha("black", 0.55)} 100%)` }} />
      <div style={{ opacity: aOut, position: "absolute", left: 140, top: 190 }}>
        <Words text="পেছন থেকে" size={86} color={theme.colors.textDim} delay={4} per={5} />
        <Words text="হাসির শব্দ" size={200} delay={14} per={6} />
      </div>
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: 0.9 * aOut }} width={1920} height={1080}>
        <path d={d} fill="none" stroke={theme.colors.hero} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 12px ${theme.colors.glowHero})` }} />
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 160, display: "flex", justifyContent: "center" }}>
        <Words text="ফিসফিস করে" size={80} color={theme.colors.textDim} delay={e19 + 6} per={6} align="center" />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 300, display: "flex", flexDirection: "column", alignItems: "center", transform: `translateX(${jit}px)` }}>
        <Words text="পরের" size={220} delay={tPor} per={5} cfg="snappy" align="center" />
        <Words text="শিকার…" size={340} color={theme.colors.accent} glow={theme.colors.glowAccent} delay={tShik} per={5} cfg="pop" rise={60} align="center" />
      </div>
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        <path d={crack} fill="none" stroke={theme.colors.text} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" opacity={0.75} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.glowHero})` }} {...drawProps(crackP)} />
      </svg>
      <AbsoluteFill style={{ background: theme.colors.black, opacity: endFade }} />
      <Sfx at={enter(s, 18) + 2} name="pop" rate={0.9} vol={0.7} />
      <Sfx at={e19 - 2} name="whooshSoft" rate={0.96} vol={0.7} />
      <Sfx at={tShik - 3} name="thud" rate={0.9} />
      <Sfx at={tShik + 6} name="chime" rate={0.75} vol={0.8} />
    </SceneShell>
  );
};
