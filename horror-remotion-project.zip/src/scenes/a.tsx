import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, withAlpha } from "../theme";
import { SceneDef, enter, within, spoken } from "../timing";
import { Entrance, Rain, SceneShell, Sfx, clampX } from "../fx";
import { MaskLine, Words, drawProps, useDraw } from "../text";
import { Pill } from "../ui";

/* ═══════════ সিন ১ — Kinetic হুক + ঘড়ি (cue ১-২) ═══════════ */
export const Scene1: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const e2 = enter(s, 2);
  const lock = 44;
  const minute = interpolate(frame, [6, lock], [-720, 0], { easing: theme.ease.out, ...clampX });
  const hour = interpolate(frame, [6, lock], [-60, 0], { easing: theme.ease.out, ...clampX });
  const pulse = interpolate(frame, [lock, lock + 6, lock + 22], [1, 1.06, 1], { easing: theme.ease.out, ...clampX });
  const clockOp = interpolate(frame, [e2, e2 + 16], [1, 0.2], { easing: theme.ease.inOut, ...clampX });
  const breathe = 1 + Math.sin(frame / 22) * 0.012;
  const ringP = useDraw(2, 34);
  const flash = interpolate(frame - (e2 + 2), [0, 2, 9], [0, 0.16, 0], clampX) + interpolate(frame - (e2 + 12), [0, 2, 8], [0, 0.07, 0], clampX);
  const rainI = interpolate(frame, [0, e2, e2 + 30], [0.12, 0.2, 1], { easing: theme.ease.inOut, ...clampX });
  return (
    <SceneShell dur={s.dur} variant={0} noWhoosh>
      <Rain intensity={rainI} opacity={0.6} />
      {/* ঘড়ি */}
      <div style={{ position: "absolute", left: 1130, top: 270, width: 540, height: 540, opacity: clockOp, transform: `scale(${pulse * breathe})` }}>
        <svg width={540} height={540} viewBox="-270 -270 540 540" style={{ overflow: "visible" }}>
          <circle r={218} fill="none" stroke={theme.colors.line} strokeWidth={3} {...drawProps(ringP)} transform="rotate(-90)" />
          {Array.from({ length: 12 }).map((_, i) => {
            const a = (i * 30 * Math.PI) / 180;
            const big = i % 3 === 0;
            const p = interpolate(frame - 8 - i * 2, [0, 10], [0, 1], { easing: theme.ease.out, ...clampX });
            const r1 = big ? 172 : 190, r2 = 204;
            return <line key={i} x1={Math.sin(a) * r1} y1={-Math.cos(a) * r1} x2={Math.sin(a) * (r1 + (r2 - r1) * p)} y2={-Math.cos(a) * (r1 + (r2 - r1) * p)} stroke={theme.colors.textDim} strokeWidth={big ? 7 : 4} strokeLinecap="round" />;
          })}
          <g transform={`rotate(${hour})`}><line x1={0} y1={14} x2={0} y2={-110} stroke={theme.colors.text} strokeWidth={13} strokeLinecap="round" /></g>
          <g transform={`rotate(${minute})`}><line x1={0} y1={22} x2={0} y2={-170} stroke={theme.colors.text} strokeWidth={8} strokeLinecap="round" /></g>
          <circle r={14} fill={theme.colors.hero} />
        </svg>
      </div>
      {/* ধাপ ১ */}
      <div style={{ position: "absolute", left: 140, top: 250 }}>
        <Words text="রাত তখন ঠিক" size={84} color={theme.colors.textDim} delay={4} per={4} exitAt={e2 - 4} />
        <div style={{ height: 6 }} />
        <Words text="বারোটা" size={300} color={theme.colors.hero} glow={theme.colors.glowHero} delay={22} cfg="pop" rise={60} exitAt={e2 - 2} />
      </div>
      {/* ধাপ ২ */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
        <MaskLine text="প্রচণ্ড" size={96} color={theme.colors.textDim} delay={e2 + 2} dur={16} />
        <MaskLine text="বৃষ্টি" size={340} delay={e2 + 8} dur={22} />
      </div>
      <AbsoluteFill style={{ background: theme.colors.white, opacity: flash, pointerEvents: "none" }} />
      <Sfx at={lock - 3} name="thud" />
      <Sfx at={e2 + 2} name="whooshSoft" rate={1.05} vol={0.8} />
    </SceneShell>
  );
};

/* ═══════════ সিন ২ — ছবির কার্ড + লাইন-মাস্ক (cue ৩) ═══════════ */
export const Scene2: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cardP = spring({ frame: frame - 2, fps, config: theme.spring.smooth });
  const float = Math.sin(frame / 30) * 6;
  const t1 = 10, t2 = within(s, 3, 0.38), t3 = within(s, 3, 0.74);
  const lineP = interpolate(frame - 6, [0, 24], [0, 1], { easing: theme.ease.out, ...clampX });
  return (
    <SceneShell dur={s.dur} variant={1}>
      <Rain intensity={0.55} opacity={0.4} />
      <div style={{ position: "absolute", left: 120, top: 200, width: 1020, height: 650, opacity: cardP, transform: `perspective(1900px) rotateY(${interpolate(cardP, [0, 1], [24, 8])}deg) translateY(${float + (1 - cardP) * 50}px) scale(${interpolate(cardP, [0, 1], [0.92, 1])})`, borderRadius: theme.radius.card, overflow: "hidden", border: `1.5px solid ${theme.colors.line}`, boxShadow: theme.shadow.card }}>
        <div style={{ position: "absolute", inset: 0 }}>
          <KB />
        </div>
        <div style={{ position: "absolute", inset: 0, background: `linear-gradient(180deg, transparent 55%, ${withAlpha("black", 0.55)})` }} />
      </div>
      <div style={{ position: "absolute", left: 1215, top: 230, width: 3, height: 600 * lineP, background: theme.colors.line, borderRadius: 3 }} />
      <div style={{ position: "absolute", left: 1270, top: 250, display: "flex", flexDirection: "column", gap: 18 }}>
        <MaskLine text="নির্জন রাস্তা" size={92} color={theme.colors.textDim} delay={t1} />
        <MaskLine text="পুরনো বাড়ি" size={128} color={theme.colors.hero} glow={theme.colors.glowHero} delay={t2} dur={22} />
        <Entrance delay={t3} rise={26} config="pop" style={{ marginTop: 26, width: "fit-content" }}>
          <Pill size={54}><span style={{ width: 16, height: 16, borderRadius: 16, background: theme.colors.accent, display: "inline-block", boxShadow: `0 0 18px ${theme.colors.glowAccent}` }} />রাফি</Pill>
        </Entrance>
      </div>
      <Sfx at={0} name="pop" rate={0.96} vol={0.85} />
      <Sfx at={t3 - 3} name="pop2" />
    </SceneShell>
  );
};
import { KenBurns } from "../fx";
const KB: React.FC = () => <KenBurns src={theme.img.house} zoomFrom={1.02} zoomTo={1.14} panX={-30} />;

/* ═══════════ সিন ৩ — Statement Card: দরজার ফলক (cue ৪) ═══════════ */
export const Scene3: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - 2, fps, config: theme.spring.smooth });
  const sway = Math.sin(frame / 38) * 1.7 + (1 - p) * 9;
  const t2 = within(s, 4, 0.52);
  const hit = frame - t2;
  const shake = hit >= 0 && hit < 12 ? Math.sin(hit * 2.4) * 9 * (1 - hit / 12) : 0;
  const numP = interpolate(frame, [4, 40], [0, 1], { easing: theme.ease.out, ...clampX });
  const stripe = (pos: "top" | "bottom"): React.CSSProperties => ({ position: "absolute", left: 0, right: 0, ...(pos === "top" ? { top: 0 } : { bottom: 0 }), height: 26, background: `repeating-linear-gradient(135deg, ${withAlpha("accent", 0.85)} 0 20px, ${withAlpha("black", 0.0)} 20px 40px)` });
  return (
    <SceneShell dur={s.dur} variant={2} warm={0.4}>
      <div style={{ position: "absolute", left: 0, right: 0, top: 70, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 820, lineHeight: 1.2, letterSpacing: 0, color: "transparent", WebkitTextStroke: `4px ${theme.colors.hero}`, opacity: 0.36 * numP, transform: `scale(${1.04 - numP * 0.04 + Math.sin(frame / 40) * 0.01})` }}>১৩</div>
      <div style={{ position: "absolute", left: 0, top: 0, width: 1920, height: 1080, transformOrigin: "960px -200px", transform: `rotate(${sway}deg) translateX(${shake}px)` }}>
        {[610, 1310].map((x, i) => (
          <div key={i} style={{ position: "absolute", left: x, top: -40, width: 6, height: 360 * p, background: theme.colors.line, borderRadius: 3 }} />
        ))}
        <div style={{ position: "absolute", left: 400, top: 320, width: 1120, height: 500, opacity: p, transform: `translateY(${(1 - p) * -60}px)`, background: withAlpha("surface", 0.62), border: `2px solid ${theme.colors.line}`, borderRadius: theme.radius.card, boxShadow: theme.shadow.card, overflow: "hidden" }}>
          <div style={stripe("top")} />
          <div style={stripe("bottom")} />
          {[[36, 52], [1052, 52], [36, 428], [1052, 428]].map(([x, y], i) => (
            <div key={i} style={{ position: "absolute", left: x, top: y, width: 18, height: 18, borderRadius: 18, background: theme.colors.line }} />
          ))}
          <div style={{ position: "absolute", left: 0, right: 0, top: 84, display: "flex", flexDirection: "column", alignItems: "center" }}>
            <Words text="তেরো নম্বর ঘরে" size={96} color={theme.colors.text} delay={10} per={6} align="center" />
            <div style={{ height: 10 }} />
            <Words text="প্রবেশ নিষেধ" size={168} color={theme.colors.accent} glow={theme.colors.glowAccent} delay={t2} per={5} cfg="pop" rise={50} align="center" />
          </div>
        </div>
      </div>
      <Sfx at={2} name="pop" rate={0.92} vol={0.8} />
      <Sfx at={t2 - 3} name="thud" rate={1.05} />
    </SceneShell>
  );
};

/* ═══════════ সিন ৪ — সিনেম্যাটিক হলওয়ে + Kinetic শব্দ (cue ৫) ═══════════ */
export const Scene4: React.FC<{ s: SceneDef }> = ({ s }) => {
  const frame = useCurrentFrame();
  const bar = interpolate(frame, [0, 22], [0, 96], { easing: theme.ease.out, ...clampX });
  const tChev = within(s, 5, 0.45);
  return (
    <SceneShell dur={s.dur} variant={3} bg={{ src: theme.img.hallway, zoomFrom: 1, zoomTo: 1.24, panX: -20, dim: 0.12 }}>
      <AbsoluteFill style={{ background: `linear-gradient(90deg, ${withAlpha("black", 0.82)} 0%, ${withAlpha("black", 0.35)} 48%, transparent 75%)` }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: bar, background: theme.colors.black }} />
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: bar, background: theme.colors.black }} />
      <div style={{ position: "absolute", left: 130, top: 360, display: "flex", flexDirection: "column", gap: 10 }}>
        <Entrance delay={4} rise={24} config="smooth" style={{ marginBottom: 14, width: "fit-content" }}>
          <Pill size={46}><span style={{ width: 14, height: 14, borderRadius: 14, background: theme.colors.accent, display: "inline-block" }} />রাফি</Pill>
        </Entrance>
        <MaskLine text="কৌতূহল" size={270} color={theme.colors.hero} glow={theme.colors.glowHero} delay={8} dur={24} />
        <div style={{ display: "flex", alignItems: "center", gap: 30, marginTop: 6 }}>
          <Words text="ভেতরে" size={96} color={theme.colors.text} delay={tChev} per={4} />
          <Chevrons delay={tChev + 6} />
        </div>
      </div>
      <Sfx at={4} name="pop" rate={1.04} />
    </SceneShell>
  );
};

const Chevrons: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  return (
    <svg width={190} height={80} viewBox="0 0 190 80">
      {[0, 1, 2].map((i) => {
        const p = interpolate(frame - delay - i * 5, [0, 14], [0, 1], { easing: theme.ease.out, ...clampX });
        const idle = 0.55 + 0.45 * Math.sin((frame - i * 7) / 9);
        return <polyline key={i} points={`${14 + i * 56},12 ${44 + i * 56},40 ${14 + i * 56},68`} fill="none" stroke={theme.colors.accent} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" opacity={p * idle} transform={`translate(${(1 - p) * -20},0)`} />;
      })}
    </svg>
  );
};
export { spoken };
