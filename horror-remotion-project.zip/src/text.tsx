import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { clampX } from "./fx";

const BN = "০১২৩৪৫৬৭৮৯";
export const toBn = (n: number | string) => String(n).replace(/\d/g, (d) => BN[+d]);

type CommonText = { size: number; weight?: number; color?: string; glow?: string; style?: React.CSSProperties };
const base = (c: CommonText): React.CSSProperties => ({
  fontFamily: theme.fonts.display,
  fontWeight: c.weight ?? theme.weight.hero,
  fontSize: c.size,
  color: c.color ?? theme.colors.text,
  letterSpacing: 0, // বাংলায় সবসময় ০
  lineHeight: 1.32,
  textShadow: c.glow ? `0 0 ${c.size * 0.28}px ${c.glow}, 0 0 ${c.size * 0.7}px ${c.glow}` : undefined,
  ...c.style,
});

/** ওয়ার্ড-বাই-ওয়ার্ড স্ট্যাগার্ড। শব্দ-বিভাজন শুধু স্পেসে, কখনো অক্ষরে নয়। */
export const Words: React.FC<
  CommonText & {
    text: string; delay?: number; per?: number; align?: "flex-start" | "center" | "flex-end";
    hi?: number[]; hiColor?: string; hiGlow?: string; cfg?: keyof typeof theme.spring; rise?: number; exitAt?: number;
  }
> = ({ text, delay = 0, per = 4, align = "flex-start", hi = [], hiColor, hiGlow, cfg = "snappy", rise = 34, exitAt, ...c }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: c.size * 0.26, rowGap: c.size * 0.02 }}>
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring[cfg] });
        const q = exitAt === undefined ? 0 : interpolate(frame, [exitAt + i, exitAt + i + theme.frames.exit], [0, 1], { easing: theme.ease.in, ...clampX });
        const isHi = hi.includes(i);
        return (
          <span key={i} style={{ ...base({ ...c, color: isHi ? hiColor ?? c.color : c.color, glow: isHi ? hiGlow ?? c.glow : c.glow }), display: "inline-block", whiteSpace: "nowrap", opacity: Math.min(1, p) * (1 - q), transform: `translateY(${interpolate(p, [0, 1], [rise, 0]) - q * 26}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`, filter: `blur(${(1 - Math.min(1, p)) * 7}px)` }}>
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** লাইন মাস্ক রিভিল: বাঁ→ডানে মাস্ক-সুইপ + সামান্য রাইজ */
export const MaskLine: React.FC<CommonText & { text: string; delay?: number; dur?: number; exitAt?: number }> = ({ text, delay = 0, dur = 20, exitAt, ...c }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame - delay, [0, dur], [0, 1], { easing: theme.ease.out, ...clampX });
  const q = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + theme.frames.exit], [0, 1], { easing: theme.ease.in, ...clampX });
  return (
    <div style={{ padding: `${c.size * 0.12}px ${c.size * 0.1}px ${c.size * 0.2}px`, margin: `-${c.size * 0.12}px -${c.size * 0.1}px -${c.size * 0.2}px`, clipPath: p >= 1 ? undefined : `inset(0 ${(1 - p) * 100}% 0 0)`, opacity: 1 - q }}>
      <div style={{ ...base(c), whiteSpace: "nowrap", transform: `translateY(${(1 - p) * 38 - q * 24}px) scale(${1 + (1 - p) * 0.03})`, transformOrigin: "left center" }}>{text}</div>
    </div>
  );
};

/** হাইলাইট সুইপ: শব্দের পেছনে রঙের পিল বাঁ→ডানে */
export const Sweep: React.FC<{ delay: number; color: string; children: React.ReactNode; dur?: number; pad?: number; radius?: number }> = ({ delay, color, children, dur = 14, pad = 18, radius = 14 }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame - delay, [0, dur], [0, 1], { easing: theme.ease.out, ...clampX });
  return (
    <span style={{ position: "relative", display: "inline-block", padding: `0 ${pad}px` }}>
      <span style={{ position: "absolute", inset: "8% 0 8% 0", background: color, borderRadius: radius, transform: `scaleX(${p})`, transformOrigin: "left center" }} />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** টাইপরাইটার (শুধু চ্যাট UI): শব্দ ধরে, জায়গা আগে থেকেই ধরা থাকে */
export const TypeWords: React.FC<CommonText & { text: string; delay?: number; per?: number }> = ({ text, delay = 0, per = 5, ...c }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: c.size * 0.26 }}>
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        return (
          <span key={i} style={{ ...base(c), display: "inline-block", whiteSpace: "nowrap", opacity: Math.min(1, p), transform: `translateY(${(1 - p) * 10}px)` }}>{w}</span>
        );
      })}
    </div>
  );
};

/** কাউন্টার রোল (শুধু স্ক্রিপ্টের সংখ্যা), বাংলা অঙ্কে */
export const BnCounter: React.FC<CommonText & { to: number; delay?: number }> = ({ to, delay = 0, ...c }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60, mass: 1 } });
  const v = Math.round(interpolate(p, [0, 1], [0, to]));
  return <span style={{ ...base(c), fontVariantNumeric: "tabular-nums", display: "inline-block" }}>{toBn(v)}</span>;
};

/** স্ট্রোক-ড্র হেল্পার */
export const useDraw = (delay: number, dur: number) => {
  const frame = useCurrentFrame();
  return interpolate(frame - delay, [0, dur], [0, 1], { easing: theme.ease.inOut, ...clampX });
};
export const drawProps = (p: number) => ({ pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - p } as const);
