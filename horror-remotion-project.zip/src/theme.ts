// theme.ts — রং, ইজিং, spring, ফন্ট, SFX: সবকিছুর একমাত্র উৎস। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
import { Easing } from "remotion";

const rgb = {
  bg: [10, 17, 18],
  hero: [95, 208, 196],
  accent: [232, 176, 74],
  text: [233, 241, 239],
  black: [0, 0, 0],
  white: [255, 255, 255],
  surface: [16, 28, 30],
} as const;
export type ColorKey = keyof typeof rgb;
export const withAlpha = (k: ColorKey, a: number) => `rgba(${rgb[k].join(",")},${a})`;

export const theme = {
  colors: {
    // স্কিম ১ — মধ্যরাতের কুয়াশা
    bg: "#0A1112",
    bgAlt: "#112325",
    bgDeep: "#050909",
    hero: "#5FD0C4",
    accent: "#E8B04A",
    text: "#E9F1EF",
    textDim: "rgba(233,241,239,0.62)",
    line: "rgba(233,241,239,0.22)",
    pale: "#BCCFCB", // মুখ/স্কেলিটনের ফ্যাকাশে রং (text থেকে সামান্য গাঢ়)
    paleDark: "#5C706F",
    black: "#000000",
    white: "#FFFFFF",
    surface: "rgba(16,28,30,0.72)",
    surfaceStroke: "rgba(95,208,196,0.28)",
    glowHero: "rgba(95,208,196,0.5)",
    glowAccent: "rgba(232,176,74,0.5)",
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "Kohinoor Bangla", sans-serif',
  },
  weight: { hero: 700, body: 600 },
  radius: { card: 28, small: 14, pill: 999 },
  shadow: {
    card: "0 40px 80px -20px rgba(0,0,0,0.7)",
    soft: "0 18px 40px -12px rgba(0,0,0,0.6)",
  },
  // মোশন-ব্যক্তিত্ব: ধীর, ভারী, সামান্য অস্বস্তিকর। লিনিয়ার নয়।
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    slow: Easing.bezier(0.22, 0.61, 0.36, 1),
  },
  spring: {
    snappy: { damping: 16, stiffness: 150, mass: 0.7 },
    smooth: { damping: 22, stiffness: 80, mass: 1.1 },
    eerie: { damping: 30, stiffness: 46, mass: 1.5 },
    pop: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  frames: { enter: 16, exit: 10 }, // ২০ ফ্রেম এন্ট্রি, ~১০ ফ্রেম এক্সিট: এক্সিট দ্রুত
  // সীমিত সেট: ৭টি সাউন্ড, একই ইভেন্টে একই সাউন্ড
  sfx: {
    pop: { file: "sfx/pop.wav", volume: 0.9 },
    pop2: { file: "sfx/pop2.wav", volume: 0.9 },
    click: { file: "sfx/click.wav", volume: 0.9 },
    whoosh: { file: "sfx/whoosh.wav", volume: 0.85 },
    whooshSoft: { file: "sfx/whoosh-soft.wav", volume: 0.9 },
    thud: { file: "sfx/thud.wav", volume: 0.85 },
    chime: { file: "sfx/chime.wav", volume: 0.9 },
  },
  img: {
    house: "img/house.jpg",
    hallway: "img/hallway.jpg",
    ghost: "img/ghost.jpg",
  },
} as const;

export type SfxName = keyof typeof theme.sfx;
