import React from "react";
import { AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, withAlpha, SfxName } from "./theme";

export const clampX = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/* ───────── SFX: ভিজ্যুয়াল ল্যান্ড করার ২-৩ ফ্রেম আগে `at` দিন ───────── */
export const Sfx: React.FC<{ at: number; name: SfxName; rate?: number; vol?: number }> = ({ at, name, rate = 1, vol = 1 }) => {
  const { fps } = useVideoConfig();
  const s = theme.sfx[name];
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={fps}>
      <Audio src={staticFile(s.file)} volume={s.volume * vol} playbackRate={rate} />
    </Sequence>
  );
};

/* ───────── লেয়ার ১: ব্যাকগ্রাউন্ড মেশ ───────── */
export const BgMesh: React.FC<{ warm?: number }> = ({ warm = 0 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 55%, ${theme.colors.bgDeep} 100%)` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -320 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${withAlpha("hero", 0.17)}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -520, right: -260 - d2, filter: "blur(80px)", background: `radial-gradient(circle, ${withAlpha("accent", 0.06 + warm * 0.14)}, transparent 65%)` }} />
    </AbsoluteFill>
  );
};

/* ───────── বৃষ্টি (প্রসিডিউরাল, ডিটারমিনিস্টিক) ───────── */
const seeded = (i: number, k: number) => {
  const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453;
  return x - Math.floor(x);
};
export const Rain: React.FC<{ intensity?: number; opacity?: number }> = ({ intensity = 0.6, opacity = 0.5 }) => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const count = Math.round(170 * Math.max(0, Math.min(1, intensity)));
  const slant = 0.16;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", opacity }}>
      <svg width={width} height={height}>
        {Array.from({ length: count }).map((_, i) => {
          const len = 50 + seeded(i, 3) * 90;
          const speed = 34 + seeded(i, 2) * 26;
          const x0 = seeded(i, 1) * (width + 400) - 200;
          const span = height + 300;
          const y = ((seeded(i, 4) * span + frame * speed) % span) - 150;
          const x = x0 - y * slant;
          return (
            <line key={i} x1={x} y1={y} x2={x - len * slant} y2={y + len} stroke={withAlpha("text", 0.1 + seeded(i, 5) * 0.28)} strokeWidth={1.5 + seeded(i, 6) * 1.5} strokeLinecap="round" />
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

/* ───────── লেয়ার ৪-৫: গ্রেড, গ্রেইন, ভিনিয়েট ───────── */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${withAlpha("black", 0.22)}, transparent 28%, transparent 70%, ${withAlpha("black", 0.3)})` }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.09, mixBlendMode: "overlay" }} />
  );
};

export const Vignette: React.FC<{ strength?: number }> = ({ strength = 0.62 }) => (
  <AbsoluteFill style={{ pointerEvents: "none", background: `radial-gradient(ellipse at center, transparent 42%, ${withAlpha("black", strength)} 100%)` }} />
);

/* ───────── স্থির ছবি: Ken Burns ───────── */
export const KenBurns: React.FC<{ src: string; zoomFrom?: number; zoomTo?: number; panX?: number; panY?: number; dim?: number; focus?: string; style?: React.CSSProperties }> = ({
  src, zoomFrom = 1, zoomTo = 1.1, panX = -25, panY = 0, dim = 0, focus = "50% 50%", style,
}) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = interpolate(frame, [0, durationInFrames], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const scale = zoomFrom + (zoomTo - zoomFrom) * t;
  return (
    <div style={{ width: "100%", height: "100%", overflow: "hidden", position: "relative", ...style }}>
      <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: focus, transformOrigin: focus, transform: `scale(${scale}) translate(${panX * t}px, ${panY * t}px)`, filter: `brightness(${1 - dim}) saturate(0.9) contrast(1.05)` }} />
    </div>
  );
};

/* ───────── প্রিমিয়াম এন্ট্রি: opacity + translateY + scale (+ blur) ───────── */
export const Entrance: React.FC<{ delay?: number; rise?: number; config?: keyof typeof theme.spring; children: React.ReactNode; style?: React.CSSProperties; exitAt?: number }> = ({
  delay = 0, rise = 40, config = "smooth", children, style, exitAt,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[config] });
  const q = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + theme.frames.exit], [0, 1], { easing: theme.ease.in, ...clampX });
  return (
    <div style={{ opacity: p * (1 - q), transform: `translateY(${interpolate(p, [0, 1], [rise, 0]) - q * 30}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`, filter: `blur(${(1 - p) * 6 + q * 5}px)`, ...style }}>{children}</div>
  );
};

/* ───────── সিন শেল: ৫ স্তরের স্ট্যাক + এন্ট্রি/এক্সিট + ট্রানজিশন whoosh ───────── */
export const SceneShell: React.FC<{
  dur: number;
  variant?: number;
  bg?: { src: string; zoomFrom?: number; zoomTo?: number; panX?: number; panY?: number; dim?: number; opacity?: number; focus?: string };
  rain?: number;
  warm?: number;
  noExit?: boolean;
  noWhoosh?: boolean;
  children: React.ReactNode;
}> = ({ dur, variant = 0, bg, rain = 0, warm = 0, noExit, noWhoosh, children }) => {
  const frame = useCurrentFrame();
  const inP = interpolate(frame, [0, theme.frames.enter], [0, 1], { easing: theme.ease.out, ...clampX });
  const outP = noExit ? 0 : interpolate(frame, [dur - theme.frames.exit, dur - 1], [0, 1], { easing: theme.ease.in, ...clampX });
  const op = inP * (1 - outP);
  const scale = interpolate(inP, [0, 1], [0.985, 1]) * (1 + outP * 0.035);
  const rates = [1, 0.95, 1.06, 0.98];
  return (
    <AbsoluteFill style={{ background: theme.colors.bgDeep }}>
      <BgMesh warm={warm} />
      <AbsoluteFill style={{ opacity: op, transform: `scale(${scale})`, filter: `blur(${outP * 6}px)` }}>
        {bg && (
          <AbsoluteFill style={{ opacity: bg.opacity ?? 1 }}>
            <KenBurns src={bg.src} zoomFrom={bg.zoomFrom} zoomTo={bg.zoomTo} panX={bg.panX} panY={bg.panY} dim={bg.dim} focus={bg.focus} />
          </AbsoluteFill>
        )}
        {rain > 0 && <Rain intensity={rain} opacity={0.55} />}
        {children}
      </AbsoluteFill>
      <Grade />
      <Grain />
      <Vignette />
      {!noWhoosh && <Sfx at={0} name="whooshSoft" rate={rates[variant % rates.length]} />}
    </AbsoluteFill>
  );
};
