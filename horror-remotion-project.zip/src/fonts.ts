// ফন্ট: আগে public/fonts/HindSiliguri-Bold.ttf (অফলাইন), না থাকলে @remotion/google-fonts।
import { continueRender, delayRender, staticFile } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const handle = delayRender("Hind Siliguri");
const done = () => continueRender(handle);

const viaGoogle = () => {
  try {
    const { waitUntilDone } = loadFont("normal", { weights: ["600", "700"], subsets: ["bengali", "latin"] });
    waitUntilDone().then(done).catch(done);
  } catch {
    done();
  }
};

try {
  const face = new FontFace("Hind Siliguri", `url(${staticFile("fonts/HindSiliguri-Bold.ttf")})`, {
    weight: "600 700",
  });
  face
    .load()
    .then((f) => {
      document.fonts.add(f);
      done();
    })
    .catch(viaGoogle);
} catch {
  viaGoogle();
}
