import React from "react";
import { theme } from "./theme";

export const Glass: React.FC<{ w?: number | string; h?: number | string; style?: React.CSSProperties; children?: React.ReactNode; stroke?: string }> = ({ w, h, style, children, stroke }) => (
  <div style={{ width: w, height: h, background: theme.colors.surface, border: `1.5px solid ${stroke ?? theme.colors.surfaceStroke}`, borderRadius: theme.radius.card, boxShadow: theme.shadow.card, backdropFilter: "blur(18px)", ...style }}>{children}</div>
);

export const Pill: React.FC<{ children: React.ReactNode; color?: string; bg?: string; size?: number; style?: React.CSSProperties }> = ({ children, color, bg, size = 40, style }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: `${size * 0.14}px ${size * 0.6}px ${size * 0.24}px`, borderRadius: theme.radius.pill, background: bg ?? theme.colors.surface, border: `1.5px solid ${theme.colors.surfaceStroke}`, fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: size, lineHeight: 1.3, letterSpacing: 0, color: color ?? theme.colors.text, ...style }}>{children}</div>
);
