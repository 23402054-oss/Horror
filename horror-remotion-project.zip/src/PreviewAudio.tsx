import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";

// এক জায়গায় চালু/বন্ধ:
export const VOICEOVER_IN_STUDIO = true; // Studio প্রিভিউতে voiceover.mp3 থাকলে বাজবে
export const VOICEOVER_IN_RENDER = false; // রেন্ডারে ডিফল্ট বন্ধ (true করলে MP4-তে মিশবে)

export const PreviewAudio: React.FC = () => {
  const rendering = getRemotionEnvironment().isRendering;
  const enabled = rendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_STUDIO;
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => (enabled && rendering ? delayRender("voiceover check") : null));

  useEffect(() => {
    if (!enabled) return;
    let dead = false;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const t = r.headers.get("content-type") || "";
        if (!dead && r.ok && /audio|mpeg|octet-stream/i.test(t)) setOk(true);
      })
      .catch(() => {})
      .finally(() => {
        if (handle !== null) continueRender(handle);
      });
    return () => {
      dead = true;
    };
  }, [enabled, handle]);

  if (!enabled || !ok) return null; // ফাইল না থাকলে নীরবে বাদ
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
