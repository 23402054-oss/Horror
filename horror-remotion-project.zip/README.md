# Horror Motion Graphics (Remotion)

1. `npm install`
2. `npx remotion studio`  → কম্পোজিশন `Main`
3. `npx remotion render src/index.ts Main out/video.mp4`

- ভয়েসওভার প্রিভিউ: `public/voiceover.mp3` রাখুন (রেন্ডারে ডিফল্ট বন্ধ; `src/PreviewAudio.tsx`-এ ফ্ল্যাগ)।
- ফন্ট অফলাইনের জন্য `public/fonts/HindSiliguri-Bold.ttf` রাখুন।
- SRT বদলালে: `npm run cues`। SFX আবার বানাতে: `npm run sfx`।
